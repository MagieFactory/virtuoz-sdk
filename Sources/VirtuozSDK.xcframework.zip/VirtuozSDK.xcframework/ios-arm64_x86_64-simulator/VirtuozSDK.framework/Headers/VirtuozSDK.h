// Created for VirtuozSDK on 2024

#import <Foundation/Foundation.h>

//! Project version number for VirtuozSDK.
//FOUNDATION_EXPORT double VirtuozSDKVersionNumber;

//! Project version string for VirtuozSDK.
//FOUNDATION_EXPORT const unsigned char VirtuozSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VirtuozSDK/PublicHeader.h>
